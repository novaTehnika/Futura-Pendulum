%{
***********************************************************************
   Script:          Motor.m
   Author:          Jeremy Simmons
   Date:            November 25, 2016
   Description:     S-Function: System dynamics for a DC motor
                    Equations of motion used are obtained from:
                    {Cazzolato, Benjamin Seth, and Zebb Prime. "On the 
                    dynamics of the Furuta pendulum." Journal of Control 
                    Science and Engineering 2011 (2011): 3.}
   Input:           
   Output:          
   Usage:           
   Known bugs/missing features:
   Modifications:
   Date                Comment            
   11/25             S-function created.
***********************************************************************
%}


%{
NOTES:

x = [       i           ]

u = [       V
            theta1      ]

y = [       tau         ]

parameters needed:  Lm,Rm,Km,theta1_0

%}

function [sys,x0,str,ts] = Motor(t,x,u,flag,...
                                        Lm,Rm,Km)

switch flag,
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes;% initialize block 
    case 1,
        sys=mdlDerivatives(t,x,u,Lm,Rm,Km); % define xdot = f(t,x,u)
    case 3,
        sys=mdlOutputs(t,x,u,Km);
    otherwise,
        sys = [];
end


%============================================================================
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates = 1;
sizes.NumDiscStates = 0;
sizes.NumOutputs = 1;
sizes.NumInputs = 2;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1; % at least one sample time is needed
sys = simsizes(sizes);

x0 = [0]; % define initial conditions
str = []; % str is always an empty matrix
% initialize the array of sample times
ts = [0 0]; % continuous sample time

%============================================================================
function xdot=mdlDerivatives(t,x,u,Lm,Rm,Km)

%%% Derivitives %%%

%{
xdot = [    idot  ]
%}

xdot(1) = (u(1) - Rm*x(1)-Km*u(2))/Lm;

%============================================================================
function y=mdlOutputs(t,x,u,Km)
y(1) = Km*x(1);


