%{
***********************************************************************
   Script:          FurutaPendulum.m
   Author:          Jeremy Simmons
   Date:            November 23, 2016
   Description:     S-Function: System dynamics for a furuta pendulum
                    Equations of motion used are obtained from:
                    {Cazzolato, Benjamin Seth, and Zebb Prime. "On the 
                    dynamics of the Furuta pendulum." Journal of Control 
                    Science and Engineering 2011 (2011): 3.}
   Input:           
   Output:          
   Usage:           
   Known bugs/missing features:
   Modifications:
   Date                Comment            
   11/23             S-function created.
***********************************************************************
%}


%{
NOTES:
theta1 is positive counter-clockwise looking down

theta2, the angle of the pendulum, is define zero in the down position and
is positive counter-clockwise

x = [       theta1
            theta2
            theta1dot
            theta2dot  ]

u = [       tau1
            tau2        ]

parameters needed:  g,m2,L1,l2,b1,b2,J0_hat,J2_hat,theta1_0,theta2_0

%}

function [sys,x0,str,ts] = FurutaPendulum(t,x,u,flag,...
                                        g,m2,L1,l2,b1,...
                                        b2,J0_hat,J2_hat,theta1_0,theta2_0)

switch flag,
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes(...
                                    theta1_0,theta2_0);% initialize block 
    case 1,
        sys=mdlDerivatives(t,x,u,...
            g,m2,L1,l2,b1,b2,J0_hat,J2_hat); % define xdot = f(t,x,u)
    case 3,
        sys=mdlOutputs(t,x,u);
    otherwise,
        sys = [];
end


%============================================================================
function [sys,x0,str,ts]=mdlInitializeSizes(theta1_0,theta2_0)
sizes = simsizes;
sizes.NumContStates = 4;
sizes.NumDiscStates = 0;
sizes.NumOutputs = 2;
sizes.NumInputs = 2;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1; % at least one sample time is needed
sys = simsizes(sizes);

x0 = [theta1_0; theta2_0; 0; 0]; % define initial conditions
str = []; % str is always an empty matrix
% initialize the array of sample times
ts = [0 0]; % continuous sample time

%============================================================================
function xdot=mdlDerivatives(t,x,u,g,m2,L1,l2,b1,b2,J0_hat,J2_hat)
%%% terms for equations of motion %%%

a_star = [  -J2_hat*b1;
            m2*L1*l2*cos(x(2))*b2;
            -J2_hat^2*sin(2*x(2));
            -0.5*J2_hat*m2*L1*l2*cos(x(2))*sin(2*x(2));
            J2_hat*m2*L1*l2*sin(x(2))                   ];
        
b_star = [  x(3);
            x(4);
            x(3)*x(4);
            x(3)^2;
            x(4)^2      ];
        
c_star = [  J2_hat;
            -m2*L1*l2*cos(x(2));
            0.5*m2^2*l2^2*L1*sin(2*x(2))    ];

d_star = [  u(1);
            u(2);
            g       ];
        
e_star = J0_hat*J2_hat + J2_hat^2*sin(x(2))^2 - m2^2*L1^2*l2^2*cos(x(2))^2;

f_star = [  m2*L1*l2*cos(x(2))*b1;
            -b2*(J0_hat + J2_hat*sin(x(2))^2);
            m2*L1*l2*J2_hat*cos(x(2))*sin(2*x(2));
            -0.5*sin(2*x(2))*(J0_hat*J2_hat + J2_hat^2*sin(x(2))^2);
            -0.5*m2^2*L1^2*l2^2*sin(2*x(2))                             ];
        
g_star = b_star;
        
h_star = [  -m2*L1*l2*cos(x(2));
            J0_hat + J2_hat*sin(x(2))^2;
            -m2*l2*sin(x(2))*(J0_hat + J2_hat*sin(x(2))^2)  ];
        
j_star = d_star;
        
l_star = e_star;


%%% Derivitives %%%

%{
xdot = [    theta1dot
            theta2dot
            theta1ddot
            theta2ddot  ]
%}

xdot(1) = x(3);
xdot(2) = x(4);
xdot(3) = (a_star'*b_star + c_star'*d_star) / e_star;
xdot(4) = (f_star'*g_star + h_star'*j_star) / l_star;

%============================================================================
function y=mdlOutputs(t,x,u)
y(1) = x(1);
y(2) = x(2);

