%{
***********************************************************************
   Script:          FurutaPendulumWithMotoUprightDesign.m
   Author:          Jeremy Simmons
   Date:            November 23, 2016
   Description:     Design process for the control of a furuta pendulum in
                    the upright position.
                    Transfer function obtained from modification made to
                    linearization performed in:
                    {Cazzolato, Benjamin Seth, and Zebb Prime. "On the 
                    dynamics of the Furuta pendulum." Journal of Control 
                    Science and Engineering 2011 (2011): 3.}
   Input:           
   Output:          
   Usage:           
   Known bugs/missing features:
   Modifications:
   Date                Comment            
   11/23             Script created.
***********************************************************************
%}

FurutaPendulumInitialize;

%%% Coefficients from linearized model %%%
d_star = J0_hat * J2_hat  -  m2^2 * L1^2 * l2^2;
A42 = g*m2*l2*J0_hat / d_star;
A44 = -b2*J0_hat / d_star;
B41 = m2*L1*l2 / d_star;

%%% Transfer Function %%%
%Pendulum
num1 = [ B41 ];
den1 = [ 1 -A44 -A42 ];

G1s = tf(num1, den1)

% Motor
num2 = [ Km/Lm ];
den2 = [ 1 Rm/Lm ];

G2s = tf(num2, den2)

% Total Fruta Pendulum
Gs = G1s*G2s

polesGs = pole(Gs);

    %Poles are at -1560, -4.5819, and 4.5286 (RHP)

%%% Begin Design %%%

% plot root locus
figure;
rlocus(Gs);

% the system can not be made stable with gain adjustment

% design a PD compensator to improve stablity
    % the zero will have to be to the left of the left most dominant 
    % pole (-4.5819)

a1 = 30;
z = [ -a1 ];
p = [ ];
Ds = zpk(z,p,1)

figure;
rlocus(Ds*Gs)

% system becomes stable at k = 11.5
% gain greater than 25 get less than 20% overshoot

k = 25
Ds = zpk(z,p,k)

Cs = feedback(Ds*Gs, 1)

figure;
step(Cs);

% there is steady-state error

% Add PI to PD (PID)

a2 = 1
z = [ -a1 -a2 ];
p = [ 0 ];
Ds = zpk(z,p,1)

figure;
rlocus(Ds*Gs)

% the gain needed for stabliiy is now 10.5
% gain for less than 20% OS is greater than 90

k = 90
Ds = zpk(z,p,k)

Cs = feedback(Ds*Gs, 1)

figure;
step(Cs);

% settling time is about 1.15 and actual overshoot is 40%
% up the gain to acheive .1 sec

k = 600;
Ds = zpk(z,p,k)

Cs = feedback(Ds*Gs, 1)

figure;
step(Cs);

% k = 400 works

Kp = k*(a1+a2)
Ki = k*a1*a2
Kd = k
