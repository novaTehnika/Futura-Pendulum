%{
***********************************************************************
   Script:          FurutaPendulumInitialize.m
   Author:          Jeremy Simmons
   Date:            November 23, 2016
   Description:     Parameters for furuta pendulum for simulation by use of
                    FurutaPendulum.m.
                    Parameters used are obtained from:
                    {Cazzolato, Benjamin Seth, and Zebb Prime. "On the 
                    dynamics of the Furuta pendulum." Journal of Control 
                    Science and Engineering 2011 (2011): 3.}
   Input:           
   Output:          
   Usage:           
   Known bugs/missing features:
   Modifications:
   Date                Comment            
   11/23             Script created.
***********************************************************************
%}

% clear memory from workspace and close figures
clc
clear all
close all

%%% NOTE: All parameters are of SI units 
%%%(i.e. m, kg, seconds, N, W, J, etc.)

%%% Initial Conditions
theta1_0 = 0;
theta2_0 = 0*pi-.01;

%%% Physics Constatants %%%

g = 9.81;   % gravity const

%%% Furuta Pendulum Parameters %%%

L1 = 0.278;         % length of arm [m]
L2 = 0.300;         % length of pendulum [m]
m1 = 0.300;         % mass of arm [kg]
m2 = 0.075;         % mass of pendulum [kg]
l1 = 0.150;         % distance to center of mass of arm [m]
l2 = 0.148;         % distance to center of mass of pendulum [m]
b1 = 1.00 * 10^-4;  % viscous friction coeff. of motor bearings [Nms]
b2 = 2.80 * 10^-4;  % viscous friction coeff. of pendulum joint [Nms]

% inertia tensor of arm
J_1 = 2.48 * 10^-2; % [kg*m^2]

J1xx = 0;
J1yy = J_1;
J1zz = J_1;

J1 = [J1xx 0 0;...
      0 J1yy 0;...
      0 0 J1zz];
  
J1_hat = J_1 + m1*l1^2; % Moment of inertia of arm about it's pivot point

% inertia tensor of pendulum
J_2 = 3.86 * 10^-3; % [kg*m^2]

J2xx = 0;
J2yy = J_2;
J2zz = J_2;

J2 = [J2xx 0 0;...
      0 J2yy 0;...
      0 0 J2zz]; 

J2_hat = J_2 + m2*l2^2; % Moment of inertia of the 
                        % pendulum about it's pivot point
  
%%% DC Motor Parameters %%%

Lm = 0.005;     % motor inductance [H]
Rm = 7.80;      % armature resistance [Ohms]
Km = 0.090;     % electromotive torque constant [Nm/A]

J0_hat = J1_hat + m2*L1^2; % Moment of inertia experienced by the servo 
                           % motor when the pendulum is in the stable 
                           % equilibrium point
