%{
***********************************************************************
   Script:          FurutaPendulumUprightDesign.m
   Author:          Jeremy Simmons
   Date:            November 23, 2016
   Description:     Design process for the control of a furuta pendulum in
                    the upright position.
                    Transfer function obtained from modification made to
                    linearization performed in:
                    {Cazzolato, Benjamin Seth, and Zebb Prime. "On the 
                    dynamics of the Furuta pendulum." Journal of Control 
                    Science and Engineering 2011 (2011): 3.}
   Input:           
   Output:          
   Usage:           
   Known bugs/missing features:
   Modifications:
   Date                Comment            
   11/23             Script created.
***********************************************************************
%}

FurutaPendulumInitialize;

%%% Coefficients from linearized model %%%
d_star = J0_hat * J2_hat  -  m2^2 * L1^2 * l2^2;
A42 = g*m2*l2*J0_hat / d_star;
A44 = -b2*J0_hat / d_star;
B41 = m2*L1*l2 / d_star;

%%% Transfer Function %%%
num = [ B41 ];
den = [ 1 -A44 -A42 ];

Gs = tf(num, den)

polesGs = pole(Gs);

    %Poles are at -4.5819 and 4.5286 (RHP)

%%% Begin Design %%%

% plot root locus
figure;
rlocus(Gs);

% at a gain of 1.32, the system becomes barely stable but the margin never
% improves

% design a PD compensator to improve stablity
    % the zero will have to be to the left of the left most pole (-4.5819)

a1 = 10;
z = [ -a1 ];
p = [ ];
Ds = zpk(z,p,1)

figure;
rlocus(Ds*Gs)

% system becomes stable at k = .13

Cs = feedback(Ds*Gs, 1)

figure;
step(Cs);

% there is steady-state error

% Add PI to PD (PID)

a2 = 1
z = [ -a1 -a2 ];
p = [ 0 ];
Ds = zpk(z,p,1)

figure;
rlocus(Ds*Gs)

% the gain needed for stabliiy is now .18

Cs = feedback(Ds*Gs, 1)

figure;
step(Cs);

% settling time is about 1.8
% up the gain to acheive .1 sec

k = 17;
Ds = zpk(z,p,k)

Cs = feedback(Ds*Gs, 1)

figure;
step(Cs);

% k = 17 works
